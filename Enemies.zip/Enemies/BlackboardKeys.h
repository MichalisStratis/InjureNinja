#pragma once

#include "Runtime/Core/Public/UObject/NameTypes.h"
#include "Runtime/Core/Public/Containers/UnrealString.h"

//-----------------------------------------------------------------------------------------------------------------------------
// Namespcae Name		: BlackboardKeys
// Author				: Michalis Stratis
// Editors				: 
// Purpose				: Stores all the Blackboard keys for the Enemy AI 
//-----------------------------------------------------------------------------------------------------------------------------
namespace BlackboardKeys
{
    TCHAR const* const chTargetLocation               = TEXT ( "TargetLocation" );
    TCHAR const* const chRetreatLocation              = TEXT ( "RetreatLocation" );
    TCHAR const* const chPlayerIsInAttackRange        = TEXT ( "PlayerIsInAttackRange" );
    TCHAR const* const chPlayerIsInMeleeRange         = TEXT ( "PlayerIsInMeleeRange" );
    TCHAR const* const chEnemyIsAttacking             = TEXT ( "EnemyIsAttacking" );
    TCHAR const* const chSumoInRange                  = TEXT ( "SumoInRange" );
    TCHAR const* const chEnemyIsSafe                  = TEXT ( "EnemyIsSafe" );
    TCHAR const* const chEnemyIsBeingAttacked         = TEXT ( "EnemyBeingAttacked" );
    TCHAR const* const chAttackTarget                 = TEXT ( "AttackTarget" );
}
