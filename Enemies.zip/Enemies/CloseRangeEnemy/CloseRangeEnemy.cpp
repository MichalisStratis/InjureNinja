// Fill out your copyright notice in the Description page of Project Settings.


#include "CloseRangeEnemy.h"
#include "Components/BoxComponent.h"
#include "Components/SphereComponent.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/Actor.h"
#include "EnemyAIController.h"
#include "InjureNinja/Enemies/LongRangeEnemy/LongRangeEnemy.h"
#include "InjureNinja/Enemies/SumoWrestler/SumoWrestler.h"
#include "InjureNinja/Enemies/LongRangeEnemy/LongRangeEnemyAIController.h"
#include "InjureNinja/Player/PlayerCharacter.h"


ACloseRangeEnemy::ACloseRangeEnemy ( const FObjectInitializer& ObjectInitializer )
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
}

void ACloseRangeEnemy::Tick ( float DeltaTime )
{
	Super::Tick ( DeltaTime );

	// Getting all overlapping actors
	GetOverlappingActors(Result,APlayerCharacter::StaticClass());

}

void ACloseRangeEnemy::BeginPlay ( )
{
	Super::BeginPlay( );

	// Setting OnComponent(Begin/End)Overlap 
	AttackCollider->OnComponentBeginOverlap.AddDynamic ( this, &ACloseRangeEnemy::OnOverlapAttackBegin );
	AttackCollider->OnComponentEndOverlap.AddDynamic ( this, &ACloseRangeEnemy::OnOverlapAttackEnd );
}

void ACloseRangeEnemy::OnOverlapAttackBegin ( UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult )
{												    
	if(OtherActor->IsA<APlayerCharacter>())
	{
		//GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Cyan, TEXT("Attack Landed"));
	}
}

void ACloseRangeEnemy::OnOverlapAttackEnd ( UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex )
{

}

void ACloseRangeEnemy::MeleeAttack()
{
	// Play montage from array based on random number
	int iRandMontage = FMath::RandRange(0, AttackMontages.Num() - 1);
	PlayAnimMontage(AttackMontages[iRandMontage], 1);

	// Cast player and damage him 
	APlayerCharacter* player = Cast<APlayerCharacter>(GetWorld()->GetFirstPlayerController()->GetPawn());
	player->DamagePlayer(20);

	// Disabling collider and setting player to null pointer
	DisableAttackBox();
	player = nullptr;

}

UAnimMontage* ACloseRangeEnemy::GetMontage( ) const
{
	// Get current active anim montage
	return GetMesh()->GetAnimInstance()->GetCurrentActiveMontage( );
}

