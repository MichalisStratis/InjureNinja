// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "InjureNinja/Enemies/EnemyBase.h"
#include "CloseRangeEnemy.generated.h"

class UBoxComponent;
class USphereComponent;
UCLASS()
class INJURENINJA_API ACloseRangeEnemy : public AEnemyBase
{
	GENERATED_BODY()
public:

    //-----------------------------------------------------------------------------------------------------------------------------
    // Function Name		:	ACloseRangeEnemy
    // Author 				:	Michalis Stratis
    // Purpose 				:	Constructor
    //-----------------------------------------------------------------------------------------------------------------------------
    ACloseRangeEnemy ( const FObjectInitializer& ObjectInitializer );

    //-----------------------------------------------------------------------------------------------------------------------------
    // Function Name		:	ACloseRangeEnemy
    // Author 				:	UE4
    // Editors              :   Michalis Stratis
    // Purpose 				:	Called every frame
    //-----------------------------------------------------------------------------------------------------------------------------
    virtual void Tick ( float DeltaTime ) override;

    // Array of anim montages
    UPROPERTY(Category = Montages, EditAnywhere, meta = (DisplayName = "Attack Montages"))
        TArray<UAnimMontage*> AttackMontages;

    //-----------------------------------------------------------------------------------------------------------------------------
    // Function Name		:	GetMontage
    // Author 				:	Michalis Stratis
    // Purpose 				:	Getter for active montage
    //-----------------------------------------------------------------------------------------------------------------------------
    UAnimMontage* GetMontage ( ) const;

    //-----------------------------------------------------------------------------------------------------------------------------
    // Function Name		:	MeleeAttack
    // Author 				:	Michalis Stratis
    // Purpose 				:	Melee attackof the enemy 
    //-----------------------------------------------------------------------------------------------------------------------------
    void MeleeAttack ();

    //-----------------------------------------------------------------------------------------------------------------------------
    // Function Name		:	BeginPlay
    // Author 				:	UE4
    // Editors              :   Michalis Stratis
    // Purpose 				:	Called on start of the game
    //-----------------------------------------------------------------------------------------------------------------------------
    virtual void BeginPlay ( ) override;

    // World
    class UWorld* m_World;

    // Array of actors
    TArray<AActor*> Result;

private:
    //-----------------------------------------------------------------------------------------------------------------------------
    // Function Name		:	OnOverlapAttackBegin, OnOverlapAttackEnd
    // Author 				:	UE4
    // Editors              :   Michalis Stratis
    // Purpose 				:	Actions when overlapping begins and end
    //-----------------------------------------------------------------------------------------------------------------------------
    UFUNCTION ( )
        void OnOverlapAttackBegin ( UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

    UFUNCTION ( )
        void OnOverlapAttackEnd(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
        //void OnHit ( UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit );

};
