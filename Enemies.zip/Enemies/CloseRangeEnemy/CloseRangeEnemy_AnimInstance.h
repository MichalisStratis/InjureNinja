// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimInstance.h"
#include "CloseRangeEnemy_AnimInstance.generated.h"

/**
 * 
 */
UCLASS()
class INJURENINJA_API UCloseRangeEnemy_AnimInstance : public UAnimInstance
{
	GENERATED_BODY()
	
};
