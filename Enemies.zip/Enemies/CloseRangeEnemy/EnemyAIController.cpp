// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemyAIController.h"
//Behaviour Tree
#include "InjureNinja/Enemies/BlackboardKeys.h"
#include "BehaviorTree/BehaviorTreeComponent.h"
#include "BehaviorTree/BehaviorTree.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "UObject/ConstructorHelpers.h"
// Perception 
#include "Perception/AISenseConfig_Sight.h"
#include "Perception/AIPerceptionStimuliSourceComponent.h"
#include "Perception/AIPerceptionComponent.h"
//Character
#include "GameFramework/Character.h"
#include "Runtime/Engine/Classes/Engine/World.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "InjureNinja/InjureNinjaCharacter.h"
#include "AIController.h"
#include "Runtime/Engine/Classes/Engine/Engine.h"


// Setup Behaviour Tree 
AEnemyAIController::AEnemyAIController ( FObjectInitializer const& object_initializer )
{
    // Find Behaviour Tree and assign to the variable
    static ConstructorHelpers::FObjectFinder<UBehaviorTree> obj ( TEXT ( "BehaviorTree'/Game/Enemy/Blueprints/BT_EnemyBehaviorTree.BT_EnemyBehaviorTree'" ) );

    if ( obj.Succeeded ( ) )
    {
        m_BehaviorTree = obj.Object;
    }

    // Create Behaviour Tree Comonent and Blackboard
    m_BehaviorTreeComponent = object_initializer.CreateDefaultSubobject<UBehaviorTreeComponent> ( this , TEXT ( "BehaviorComp" ) );
    m_Blackboard = object_initializer.CreateDefaultSubobject<UBlackboardComponent> ( this , TEXT ( "BlackboardComp" ) );

}

// Run Behaviour Tree
void AEnemyAIController::BeginPlay ( )
{
    Super::BeginPlay ( );

    // Run Behaviour Tree
    RunBehaviorTree ( m_BehaviorTree );
    m_BehaviorTreeComponent->StartTree ( *m_BehaviorTree );
}

// Initialize blackboard 
void AEnemyAIController::OnPossess ( APawn* const pawn )
{
    Super::OnPossess ( pawn );

    // Initialize blackboard 
    if ( m_Blackboard )
    {
        m_Blackboard->InitializeBlackboard ( *m_BehaviorTree->BlackboardAsset );
    }
}

// Getter for Blackboard
UBlackboardComponent* AEnemyAIController::GetBlackboard ( ) const
{
    return m_Blackboard;
}

void AEnemyAIController::OnUpdateMeleeRange( bool bbkey_result )
{   
    // Change value of bbkey
    GetBlackboard()->SetValueAsBool(BlackboardKeys::chPlayerIsInMeleeRange,bbkey_result);
}

void AEnemyAIController::OnUpdateBeingAttacked( bool bbkey_result )
{    
    // Change value of bbkey
    GetBlackboard()->SetValueAsBool(BlackboardKeys::chEnemyIsBeingAttacked,bbkey_result);
}