// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "EnemyAIController.generated.h"

/**
 * 
 */
class UNavigationSystemV1;
UCLASS()
class INJURENINJA_API AEnemyAIController : public AAIController
{
	GENERATED_BODY()

public:
    AEnemyAIController ( FObjectInitializer const& object_initializer );

    //-----------------------------------------------------------------------------------------------------------------------------
    // Function Name		: BeginPlay
    // Author				: UE4
    // Editors				: Michalis Stratis
    // Purpose				: Run Behaviour Tree
    //-----------------------------------------------------------------------------------------------------------------------------
    void BeginPlay ( ) override;

    UNavigationSystemV1* NavArea;
    //-----------------------------------------------------------------------------------------------------------------------------
    // Function Name		: OnPossess
    // Author				: UE4
    // Editors				: Michalis Stratis
    // Parameters			: APawn
    // Purpose				: Initialize blackboard 
    //-----------------------------------------------------------------------------------------------------------------------------
    void OnPossess ( APawn* const Pawn ) override;


    void OnUpdateMeleeRange ( bool bbkey_result );
    void OnUpdateBeingAttacked ( bool bbkey_result );

    //-----------------------------------------------------------------------------------------------------------------------------
    // Function Name		: GetBlackboard
    // Author				: Michalis Stratis
    // Editors				: 
    // Purpose				: Getter for Blackboard
    //-----------------------------------------------------------------------------------------------------------------------------
    UBlackboardComponent* GetBlackboard ( ) const;

protected:

    // Behaviour Tree
    UPROPERTY ( EditInstanceOnly , BlueprintReadWrite )
        class UBehaviorTree* m_BehaviorTree;

    // Behaviour Tree Component
    UPROPERTY ( EditInstanceOnly , BlueprintReadWrite )
        class UBehaviorTreeComponent* m_BehaviorTreeComponent;

    // Blackboard Component
    class UBlackboardComponent* m_Blackboard;
	
};
