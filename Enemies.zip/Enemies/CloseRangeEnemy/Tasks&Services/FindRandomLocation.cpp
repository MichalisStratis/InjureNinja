// Fill out your copyright notice in the Description page of Project Settings.


#include "FindRandomLocation.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Runtime/NavigationSystem/Public/NavigationSystem.h"
#include "InjureNinja/Enemies/CloseRangeEnemy/EnemyAIController.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Vector.h"
#include "GameFramework/Character.h"
#include "InjureNinja/Enemies/BlackboardKeys.h"

UFindRandomLocation::UFindRandomLocation(FObjectInitializer const& object_initializer)
{
	// Naming the node in engine
	NodeName = TEXT("Find Random Location");
}

EBTNodeResult::Type UFindRandomLocation::ExecuteTask(UBehaviorTreeComponent& owner_comp, uint8* node_memory)
{
	// get player character and the NPC's controller
	ACharacter* const player = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
	auto const cont = Cast<AEnemyAIController>(owner_comp.GetAIOwner());

	// get player location to use as an origin
	FVector const player_location = player->GetActorLocation();

	// find random x and y numbers and add the to form new vector
	FNavLocation loc;
	int iRandX=FMath::RandRange ( -200,200 );
	int iRandY=FMath::RandRange ( -200,200 );
	FVector v3PlayerPosition = FVector ( player_location.X + iRandX, player_location.Y + iRandX, player_location.Z );

	// get the n0avigation system and generate a random location near the player
	UNavigationSystemV1* const nav_sys = UNavigationSystemV1::GetCurrent(GetWorld());

	// Setting result as the target location
	cont->GetBlackboard()->SetValueAsVector(BlackboardKeys::chTargetLocation, v3PlayerPosition);

	// finish with success
	FinishLatentTask(owner_comp, EBTNodeResult::Succeeded);
	return EBTNodeResult::Succeeded;
}
