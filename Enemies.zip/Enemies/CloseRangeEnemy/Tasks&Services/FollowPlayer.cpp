// Fill out your copyright notice in the Description page of Project Settings.


#include "FollowPlayer.h"
#include "InjureNinja/Enemies/CloseRangeEnemy/EnemyAIController.h"
#include "InjureNinja/Enemies/EnemyBase.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Blueprint/AIBlueprintHelperLibrary.h"
#include "InjureNinja/Enemies/BlackBoardKeys.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "Runtime/Engine/Classes/Kismet/KismetMathLibrary.h"

UFollowPlayer::UFollowPlayer(FObjectInitializer const& object_initializer)
{
	NodeName = TEXT("Follow Player");
}

EBTNodeResult::Type UFollowPlayer::ExecuteTask(UBehaviorTreeComponent& owner_comp, uint8* node_memory)
{
	// get TargetLocation from blackboard via AI controller
	AEnemyAIController* const cont = Cast<AEnemyAIController>(owner_comp.GetAIOwner());	  
	FVector const player_location = GetWorld()->GetFirstPlayerController( )->GetPawn( )->GetActorLocation( );

	// move to the player's location
	cont->MoveToLocation(player_location, m_fAcceptance_Radius, true);

	// finish with success
	FinishLatentTask(owner_comp, EBTNodeResult::Succeeded);
	return EBTNodeResult::Succeeded;
}
