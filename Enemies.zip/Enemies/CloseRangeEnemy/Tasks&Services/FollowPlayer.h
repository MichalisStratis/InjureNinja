// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/Tasks/BTTask_BlackboardBase.h"
#include "FollowPlayer.generated.h"

/**
 * 
 */
UCLASS(Blueprintable)
class INJURENINJA_API UFollowPlayer : public UBTTask_BlackboardBase
{
	GENERATED_BODY()
public:
	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	UFollowPlayer
	// Author 				:	Michalis Stratis
	// Purpose 				:	Constructor
	//-----------------------------------------------------------------------------------------------------------------------------
	UFollowPlayer(FObjectInitializer const& object_initializer);

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	ExecuteTask
	// Author 				:	UE4
	// Editors              :   Michalis Stratis
	// Purpose 				:	Function that executes task for the behaviour tree.
	//-----------------------------------------------------------------------------------------------------------------------------
	EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& owner_comp, uint8* node_memory) override;
private:
	// Acceptance radius
	UPROPERTY ( EditAnywhere, BlueprintReadWrite, Category = "Distance ", meta = ( AllowPrivateAccess = "true" ) )
		float m_fAcceptance_Radius;

	
};
