
#include "MeleeAttack.h"
#include "AIController.h"
#include "InjureNinja/Enemies/CloseRangeEnemy/EnemyAIController.h"
#include "InjureNinja/Enemies/CloseRangeEnemy/CloseRangeEnemy.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Runtime/Engine/Classes/Engine/World.h"
#include "Engine/LatentActionManager.h"
#include "Components/SkeletalMeshComponent.h"
#include "Animation/AnimMontage.h"
#include "Animation/AnimInstance.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "GameFramework/Character.h"
#include "Runtime/Engine/Classes/Engine/World.h"
#include "InjureNinja/Enemies/BlackboardKeys.h"
#include "BehaviorTree/BlackboardComponent.h"
#include <cmath>


UMeleeAttack::UMeleeAttack(FObjectInitializer const& object_initializer)
{
	// Naming node in engine
	NodeName = TEXT("Melee Attack");
}

EBTNodeResult::Type UMeleeAttack::ExecuteTask(UBehaviorTreeComponent& owner_comp, uint8* node_memory)
{
	// get NPC
	AEnemyAIController* const cont = Cast<AEnemyAIController>(owner_comp.GetAIOwner());
	ACloseRangeEnemy* const npc = Cast<ACloseRangeEnemy>(cont->GetPawn());
	
	if (!MontageFinished(npc))
	{
		// CAttacking the player, setting the bbkey to its relevant value and ending the task succesfully
		npc->MeleeAttack();
		cont->GetBlackboard()->SetValueAsBool(BlackboardKeys::chEnemyIsAttacking, true);
		FinishLatentTask(owner_comp, EBTNodeResult::Succeeded);
		return EBTNodeResult::Succeeded;
	}
	return EBTNodeResult::Failed;
}

bool UMeleeAttack::MontageFinished(ACloseRangeEnemy* const npc)
{
	// Returns if montage is still playing 
	return npc->GetMesh()->GetAnimInstance()->IsAnyMontagePlaying();
}
