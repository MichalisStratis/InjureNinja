// Fill out your copyright notice in the Description page of Project Settings.


#include "PlayerInMeleeRange.h"
#include "InjureNinja/Enemies/CloseRangeEnemy/EnemyAIController.h"
#include "InjureNinja/Enemies/CloseRangeEnemy/CloseRangeEnemy.h"
#include "InjureNinja/InjureNinjaCharacter.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "GameFramework/Character.h"
#include "Runtime/Engine/Classes/Engine/World.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "InjureNinja/Enemies/BlackboardKeys.h"
#include <cmath>

UPlayerInMeleeRange::UPlayerInMeleeRange ( )
{
    // Naming node in engine
    NodeName = TEXT("Is Player In Melee Range");
}

void UPlayerInMeleeRange::TickNode ( UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds )
{
    Super::TickNode ( OwnerComp , NodeMemory , DeltaSeconds );

    // Get AI Controller and Enemy Pawn
    auto const controller = Cast<AEnemyAIController> ( OwnerComp.GetAIOwner ( ) );
    auto const npc = Cast<AEnemyBase> ( controller->GetPawn ( ) );

    // Find player's Location
    FVector attackTargetLocation = GetWorld()->GetFirstPlayerController( )->GetPawn( )->GetActorLocation( );

    // Calculate distance between enemy and player
    auto distanceToAttackLocation = FVector::Dist ( npc->GetActorLocation ( ) , attackTargetLocation );

    // Compare with melee range and assign appropriate value to bbkey
    if ( distanceToAttackLocation <= melee_range )
    {
        controller->OnUpdateMeleeRange ( true );
    }
    else
    {
        controller->OnUpdateMeleeRange ( false );
    }
}
