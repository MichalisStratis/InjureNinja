// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/Services/BTService_BlackboardBase.h"
#include "PlayerInMeleeRange.generated.h"

/**
 * 
 */
UCLASS(Blueprintable)
class INJURENINJA_API UPlayerInMeleeRange : public UBTService_BlackboardBase
{
	GENERATED_BODY()
public:
	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	UPlayerInMeleeRange
	// Author 				:	Michalis Stratis
	// Purpose 				:	Constructor
	//-----------------------------------------------------------------------------------------------------------------------------
	UPlayerInMeleeRange();		 

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	TickNode
	// Author 				:	UE4
	// Editors              :   Michalis Stratis
	// Purpose 				:	Function that gets called every frame and updates bbkeys.
	//-----------------------------------------------------------------------------------------------------------------------------
	void TickNode ( UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds ) override;

private:
	// Melee range of the player
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = AI, meta = (AllowPrivateAccess = "true"))
		float melee_range = 100.0f;
	
};
