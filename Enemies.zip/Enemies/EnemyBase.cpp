// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemyBase.h"
#include "Components/CapsuleComponent.h"
#include "Components/BoxComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include <Kismet/GameplayStatics.h>
#include "InjureNinja/Player/PlayerCharacter.h"
#include "InjureNinja/Enemies/WaveSystem.h"
#include "Camera/CameraComponent.h"
#include "InjureNinja/InjureNinjaProjectile.h"
#include "InjureNinja/Enemies/LongRangeEnemy/LongRangeEnemyAIController.h"
#include "InjureNinja/InjureNinjaCharacter.h"
#include "BlackboardKeys.h"
#include "GameFramework/CharacterMovementComponent.h"

// Sets default values
AEnemyBase::AEnemyBase()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//Create sphere component and set sphere radius
	AttackCollider=CreateDefaultSubobject<UBoxComponent>(TEXT("Box Colliders"));
	AttackCollider->SetBoxExtent (FVector( 20.f, 20.f, 20.f ));
	AttackCollider->GetGenerateOverlapEvents ( );
	AttackCollider->SetupAttachment(GetMesh());
	AttackCollider->SetCollisionEnabled ( ECollisionEnabled::QueryOnly );
}

void AEnemyBase::EnableAttackBox()
{
	AttackCollider->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	//GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, TEXT("Enemy box enabled"));
}

void AEnemyBase::DisableAttackBox()
{
	AttackCollider->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	//GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, TEXT("Enemy box disabled"));
}

// Called when the game starts or when spawned
void AEnemyBase::BeginPlay()
{
	Super::BeginPlay();

	// Get World
	m_pcWorld = GetWorld ( );

	// Get the player character in the scene.
	m_pcPlayerCharacter = Cast<APlayerCharacter>(UGameplayStatics::GetActorOfClass(GetWorld(), APlayerCharacter::StaticClass()));
	m_pcWaveSystem = Cast<AWaveSystem>(UGameplayStatics::GetActorOfClass(GetWorld(), AWaveSystem::StaticClass()));

	// Sets the current health to the enemies default health.
	m_iCurrentHealth = iHealth;

	DisableEnemy();
}

// Called every frame
void AEnemyBase::Tick(float DeltaTime)
{
	Super::Tick ( DeltaTime );

}

// Called to bind functionality to input
void AEnemyBase::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}

void AEnemyBase::DamageEnemy(int iDamage)
{
	// Damage the enemy.
	m_iCurrentHealth -= iDamage;

	// Check health.
	if ( m_iCurrentHealth <= 0)
	{
		// Initialise the ragdoll effect.
		Ragdoll ( );

		//m_bActive = false;
		m_pcWaveSystem->EnemyKilled ( );
	}
	else
	{
		// Take damage animation and sound effect.
	}
}

void AEnemyBase::Ragdoll()
{
	// Set the correct collision and channel settings.
	GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	GetCapsuleComponent()->SetCollisionResponseToAllChannels(ECR_Ignore);
	GetCapsuleComponent()->SetActive(false);

	// Set collision profile to ragdoll.
	GetMesh()->SetCollisionProfileName(FName(TEXT("Ragdoll")));

	// Allow only the mesh of the enmy to react to the environment and not the capsule collider.
	SetActorEnableCollision(true);

	// Set the correct mesh properties.
	GetMesh()->SetAllBodiesSimulatePhysics(true);
	GetMesh()->SetSimulatePhysics(true);
	GetMesh()->WakeAllRigidBodies();
	GetMesh()->bBlendPhysics = true;
	GetMesh()->AddForce(m_pcPlayerCharacter->GetCamera()->GetForwardVector() * 2500000);
	GetMesh()->AddForce(FVector(0, 0, 2000000));

	DisableEnemyMovement();

	GetWorldTimerManager().SetTimer(m_pcResetTimer, this, &AEnemyBase::DisableEnemy, 5, false);

	// TEMP - TODO, call a function after 'x' amount of seconds to reset the player and hide until needed again.
	//SetLifeSpan(5.f);
}

void AEnemyBase::Reset()
{
	m_iCurrentHealth = iHealth;

	// Set movement and capsule component properties.
	GetCharacterMovement()->SetMovementMode(EMovementMode::MOVE_Walking);
	GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	GetCapsuleComponent()->SetCollisionProfileName("Pawn");
	GetCapsuleComponent()->SetActive(true);

	// Set mesh properties.
	GetMesh()->SetAllBodiesSimulatePhysics(false);
	GetMesh()->SetSimulatePhysics(false);
	GetMesh()->bBlendPhysics = false;
	GetMesh()->SetCollisionObjectType(ECollisionChannel::ECC_Pawn);
	GetMesh()->SetCollisionEnabled(ECollisionEnabled::QueryOnly);

	// Set collision profile to ragdoll.
	GetMesh()->SetCollisionProfileName(FName(TEXT("CharacterMesh")));

	// Adjust capsule component position to where the player mesh is.
	GetCapsuleComponent()->SetWorldLocation(GetMesh()->GetComponentLocation());

	// Attack the mesh to the capsule component.
	GetMesh()->AttachToComponent(GetCapsuleComponent(), FAttachmentTransformRules::KeepRelativeTransform);

	// Set relative rotation and location of the mesh.
	GetMesh()->SetRelativeLocation(FVector(0, 0.000856, -95));
	GetMesh()->SetRelativeRotation(FRotator(0, 270, 0));

	// Enable character movement tick.
	GetCharacterMovement()->SetComponentTickEnabled(true);
}

void AEnemyBase::SpawnEnemy(FVector v3SpawnPosition)
{
	// Reset the enemy properties.
	Reset();

	// Change position to spawn location.
	SetActorLocation(v3SpawnPosition);

	// Toggle mesh and enable tick and movement.
	GetMesh()->SetVisibility(true);
	GetController()->SetActorTickEnabled(true);
	GetCharacterMovement()->SetAutoActivate(true);

	// Michalis' Speed Randomisation
	RandomiseSpeed ( );

	// Set the actor active.
	PrimaryActorTick.bCanEverTick = true;
	m_bActive = true;
}

void AEnemyBase::DisableEnemy()
{
	// Disable enemy active state.
	m_bActive = false; 
	PrimaryActorTick.bCanEverTick = false;

	// Disable mesh visibility.
	GetMesh()->SetVisibility(false);

	// Move actor away from the scene.
	SetActorLocation(FVector(1000000, 100000, 100000));

	// Disable actors controller tick.
	GetController()->SetActorTickEnabled(false);

	// Disable attack box and movement.
	DisableAttackBox();
	DisableEnemyMovement();

	// Stop movement activation.
	GetCharacterMovement()->SetAutoActivate(false);
}

void AEnemyBase::DisableEnemyMovement()
{
	// Disable enemy movement.
	GetCharacterMovement()->StopMovementImmediately();
	GetCharacterMovement()->DisableMovement();
	GetCharacterMovement()->SetComponentTickEnabled(false);
}

void AEnemyBase::RandomiseSpeed ( )
{
	if ( GetType ( ) == CloseRange ) 
	{
		GetCharacterMovement ( )->MaxWalkSpeed = FMath::RandRange ( 500, 700 );
	}
	else if ( GetType ( ) == LongRange )
	{
		GetCharacterMovement ( )->MaxWalkSpeed = FMath::RandRange ( 700, 900 );
	}
	else if ( GetType ( ) == Sumo )
	{
		GetCharacterMovement ( )->MaxWalkSpeed = 250;
	}
}

TEnumAsByte<EnemyType> AEnemyBase::GetType()
{
	return Type;
}

bool AEnemyBase::GetActiveState()
{
	return m_bActive;
}

void AEnemyBase::SetActiveState(bool bActiveState)
{
	m_bActive = bActiveState;
}


