// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "EnemyBase.generated.h"

class APlayerCharacter;
class AWaveSystem;
class AInjureNinjaProjectile;
class UBoxComponent;

UENUM(BlueprintType)
enum EnemyType {
	CloseRange      UMETA(DisplayName = "Close Range"),
	LongRange		UMETA(DisplayName = "Long Range"),
	Sumo			UMETA(DisplayName = "Sumo")
};

UCLASS()
class INJURENINJA_API AEnemyBase : public ACharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	AEnemyBase();

	// Max health of enemy.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Properties", meta = (DisplayName = "Health"))
		int iHealth;

	// Type of enemy.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Properties", meta = (DisplayName = "Enemy Type"))
		TEnumAsByte<EnemyType> Type;

	
	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	EnableAttackBox
	// Author 				:	Kurtis Watson
	// Purpose 				:	Function that is called to enable the attack box of the enemy.
	//-----------------------------------------------------------------------------------------------------------------------------
	UFUNCTION(BlueprintCallable)
	void EnableAttackBox ( );

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	DisableAttackBox
	// Author 				:	Kurtis Watson
	// Purpose 				:	Function that is called to disable the attack box of the enemy.
	//-----------------------------------------------------------------------------------------------------------------------------
	UFUNCTION(BlueprintCallable)
	void DisableAttackBox ( );

protected:
	// Reference to the player character.
	APlayerCharacter* m_pcPlayerCharacter;

	// Setting a box collider component as a UProperty
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Colliders")
		UBoxComponent* AttackCollider;

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	OnBeginOverlapTrigger
	// Author 				:	Unreal Engine
	// Purpose 				:	Function that is called at game start.
	//-----------------------------------------------------------------------------------------------------------------------------
	virtual void BeginPlay() override;

	// World reference.
	class UWorld* m_pcWorld;

	// Reset enemy timer.
	FTimerHandle m_pcResetTimer;

	// Spawn Rotation
	UPROPERTY ( )
		FRotator m_vSpawnRotation;

	// Spawn Location
	UPROPERTY ( )
		FVector	m_vSpawnLocation;

public:	
	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	Tick
	// Author 				:	Unreal Engine
	// Purpose 				:	Function that is called on collision.
	// Parameters			:	DeltaTime - Describes the time difference between the previous frame that was drawn and the 
	//							current frame.
	//-----------------------------------------------------------------------------------------------------------------------------
	virtual void Tick(float DeltaTime) override;

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	SetupPlayerInputComponent
	// Author 				:	Kurtis Watson
	// Purpose 				:	Sets up the player input responses.
	// Parameters			:	PlayerInputComponent - Gets the input manager in engine.
	//-----------------------------------------------------------------------------------------------------------------------------
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;


	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	DamageEnemy
	// Author 				:	Kurtis Watson
	// Purpose 				:	Damages the enemy.
	// Parameters			:	iDamage - The damage to hurt the enemy by.
	//-----------------------------------------------------------------------------------------------------------------------------
	void DamageEnemy(int iDamage);

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	Ragdoll
	// Author 				:	Kurtis Watson
	// Purpose 				:	Called to trigger the ragdoll properties (called when killed).
	//-----------------------------------------------------------------------------------------------------------------------------
	void Ragdoll();

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	Reset
	// Author 				:	Kurtis Watson
	// Purpose 				:	
	//-----------------------------------------------------------------------------------------------------------------------------
	void Reset();

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	SpawnEnemy
	// Author 				:	Kurtis Watson
	// Purpose 				:	
	//-----------------------------------------------------------------------------------------------------------------------------
	void SpawnEnemy(FVector v3SpawnPosition);

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	DisableEnemy
	// Author 				:	Kurtis Watson
	// Purpose 				:	
	//-----------------------------------------------------------------------------------------------------------------------------
	void DisableEnemy();

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	GetType
	// Author 				:	Kurtis Watson
	// Purpose 				:	
	//-----------------------------------------------------------------------------------------------------------------------------
	TEnumAsByte<EnemyType> GetType();
	
	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	GetActiveState | SetActiveState
	// Author 				:	Kurtis Watson
	// Purpose 				:	
	//-----------------------------------------------------------------------------------------------------------------------------
	UFUNCTION(BlueprintCallable)
	bool GetActiveState();
	void SetActiveState(bool bActiveState);

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	Radomise Enemy Speed
	// Author 				:	Michalis Stratis
	// Purpose 				:	Randomises enemy speed on spawn
	//-----------------------------------------------------------------------------------------------------------------------------
	void RandomiseSpeed();

private:
	// Reference to wave system.
	AWaveSystem* m_pcWaveSystem;

	// Stores current health.
	int m_iCurrentHealth;

	// Enemy active state.
	bool m_bActive;

	// Called to disable the enemy from moving.
	void DisableEnemyMovement();
};
