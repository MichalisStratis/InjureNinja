// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemyShuriken.h"
#include "InjureNinja/Player/PlayerCharacter.h"
#include "Components/SphereComponent.h"
#include "InjureNinja/Player/PlayerAnimInstance.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "InjureNinja/Tools/Lerp.h"
#include <Kismet/GameplayStatics.h>
#include "Engine/Texture.h"
#include "InjureNinja/Enemies/EnemyBase.h"

// Sets default values
AEnemyShuriken::AEnemyShuriken()
{
	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	// Cast to the necessary classes in engine.
	m_pcPlayerCharacter = Cast<APlayerCharacter>(UGameplayStatics::GetActorOfClass(GetWorld(), APlayerCharacter::StaticClass()));

	// Create a static mesh component and set its properties.
	Mesh = CreateDefaultSubobject<UStaticMeshComponent>("Mesh");
	// Players can't walk on it
	Mesh->SetWalkableSlopeOverride(FWalkableSlopeOverride(WalkableSlope_Unwalkable, 0.f));
	Mesh->CanCharacterStepUpOn = ECB_No;

	// Create sphere component and set sphere radius
	Collider=CreateDefaultSubobject<USphereComponent>(TEXT("Box Colliders"));
	Collider->SetSphereRadius ( 150.f );
	Collider->GetGenerateOverlapEvents ( );
	Collider->SetCollisionEnabled ( ECollisionEnabled::QueryOnly );
	Collider->SetupAttachment(Mesh);

	// Setting mesh as root component
	RootComponent = Mesh;
}

void AEnemyShuriken::OnOverlapBegin ( UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult )
{
	// If it collides with the player set state to inactive, destroy actor and damage player
	if ( OtherActor->IsA<APlayerCharacter> ( ) )
	{
		m_bIsActive = false;
		Destroy ( );
		m_pcPlayerCharacter->DamagePlayer(20);
	}
		
}

void AEnemyShuriken::BeginPlay ( )
{
	Super::BeginPlay ( );
	Collider->OnComponentBeginOverlap.AddDynamic(this, &AEnemyShuriken::OnOverlapBegin);	
}

void AEnemyShuriken::DettachToPlayerHand( )
{
	// Dettaches actor from socket
	Mesh->DetachFromComponent(FDetachmentTransformRules::KeepRelativeTransform);
}

void AEnemyShuriken::Tick ( float DeltaTime)
{
	// Moves towards target
	Super::Tick(DeltaTime);
	TrackTarget ( Mesh, DeltaTime );
}

UStaticMeshComponent* AEnemyShuriken::GetMesh()
{
	return Mesh;
}
