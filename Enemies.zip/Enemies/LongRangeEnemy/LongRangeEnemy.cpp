   // Fill out your copyright notice in the Description page of Project Settings.


#include "LongRangeEnemy.h"
#include "LongRangeEnemyAIController.h"
#include "Components/BoxComponent.h"
#include "InjureNinja/Player/PlayerCharacter.h"
#include "Components/SphereComponent.h"
#include "InjureNinja/Enemies/LongRangeEnemy/EnemyShuriken.h"
#include "InjureNinja/InjureNinjaProjectile.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "InjureNinja/Tools/Lerp.h"
#include "DrawDebugHelpers.h"


ALongRangeEnemy::ALongRangeEnemy ( const FObjectInitializer& ObjectInitializer )
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}
void ALongRangeEnemy::BeginPlay ( )
{
	Super::BeginPlay();

	AttackCollider->OnComponentBeginOverlap.AddDynamic ( this, &ALongRangeEnemy::OnOverlapAttackBegin );
	AttackCollider->OnComponentEndOverlap.AddDynamic ( this, &ALongRangeEnemy::OnOverlapAttackEnd );
}
void ALongRangeEnemy::Tick ( float DeltaTime )
{
	Super::Tick ( DeltaTime );
}

void ALongRangeEnemy::OnOverlapAttackBegin ( UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult )
{
	// Jumps if collidre detects player
	if(OtherActor->IsA<APlayerCharacter>())
	{
		Jump ( );
	}
}

void ALongRangeEnemy::OnOverlapAttackEnd ( UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex )
{
}

UAnimMontage* ALongRangeEnemy::GetMontage ( ) const
{
	return ThrowMontage;
}

void ALongRangeEnemy::LongRangeAttack ( )
{
	// Finds actor location and rotation 
	const FVector loc = GetActorLocation ( ) + m_vSpawnLocationOffset;
	const FRotator rot = GetActorRotation ( );

	// Setting spawning parameters and attachment rules
	FActorSpawnParameters actorSpawnParams;
	actorSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	FAttachmentTransformRules AttachmentRules(EAttachmentRule::SnapToTarget, true);

	// Spawning shuriken actors, attaching it to Shuriken sockket and setting the player as the target
	AEnemyShuriken* pcShuriken = GetWorld ( )->SpawnActor<AEnemyShuriken> ( Shuriken, loc, rot, actorSpawnParams );
	pcShuriken->GetMesh()->SetRelativeTransform(GetMesh()->GetSocketTransform(FName("Shuriken")));
	pcShuriken->SetTarget ( m_pcPlayerCharacter->GetActorLocation() );

	// Line trace
	FHitResult OutHit;
	FVector Start = GetActorLocation ( ) + m_vSpawnLocationOffset;
	FVector forward = GetActorForwardVector ( );
	FVector End = ( ( forward * 1000 ) + Start );
	FCollisionQueryParams params;

	DrawDebugLine ( GetWorld ( ), Start, End, FColor::Red, true );
	bool isHit = GetWorld ( )->LineTraceSingleByChannel ( OutHit, Start, End, ECC_Visibility, params );
	
}

