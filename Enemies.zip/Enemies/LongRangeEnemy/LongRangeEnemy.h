// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "InjureNinja/Enemies/EnemyBase.h"
#include "LongRangeEnemy.generated.h"

class USphereComponent;
class AEnemyShuriken;

UCLASS()
class INJURENINJA_API ALongRangeEnemy : public AEnemyBase
{
	GENERATED_BODY()

public:
	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	ALongRangeEnemy
	// Author 				:	Michalis Stratis
	// Purpose 				:	Constructor
	//-----------------------------------------------------------------------------------------------------------------------------
	ALongRangeEnemy ( const FObjectInitializer& ObjectInitializer );

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	GetMontage
	// Author 				:	Michalis Stratis
	// Purpose 				:	Getter for ThrowMontage
	//-----------------------------------------------------------------------------------------------------------------------------
	UAnimMontage* GetMontage ( ) const;

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	LongRangeAttack
	// Author 				:	Michalis Stratis
	// Purpose 				:	Spawns enemy suriken to attack player
	//-----------------------------------------------------------------------------------------------------------------------------
	UFUNCTION( BlueprintCallable )
		void LongRangeAttack ( );

protected:
	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	BeginPlay
	// Author 				:	UE4
	// Editors              :   Michalis Stratis
	// Purpose 				:	Gets called when the game begins.
	//-----------------------------------------------------------------------------------------------------------------------------
	virtual void BeginPlay() override;

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	Tick
	// Author 				:	UE4
	// Editors              :   Michalis Stratis
	// Purpose 				:	Gets called every frame.
	//-----------------------------------------------------------------------------------------------------------------------------
	virtual void Tick ( float DeltaTime ) override;

	// Offset from the Bone Location
	UPROPERTY ( EditAnywhere , BlueprintReadWrite , Category = "Projectile Attack Sequence Properties [DEPRECATED]" ,
				meta = ( DisplayName = "Spawn Location Offset" , ToolTip = "Offset from the bone location, NOTE: Not using currently" ) )
		FVector	m_vSpawnLocationOffset;

private:

	// Throw montage
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation ", meta = (AllowPrivateAccess = "true"))
		UAnimMontage* ThrowMontage;	 

	// Shuriken subclass
	UPROPERTY(EditDefaultsOnly, Category=Projectile, meta=(AllowPrivateAccess="true") )
		TSubclassOf<AEnemyShuriken> Shuriken;

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	OnOverlapAttackBegin
	// Author 				:	Unreal Engine
	// Purpose 				:	Function that is called on collision.
	//-----------------------------------------------------------------------------------------------------------------------------
	UFUNCTION ( )
		void OnOverlapAttackBegin ( UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	OnOverlapAttackEnd
	// Author 				:	Unreal Engine
	// Purpose 				:	Function that is called on collision.
	//-----------------------------------------------------------------------------------------------------------------------------
	UFUNCTION ( )
		void OnOverlapAttackEnd(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
};
