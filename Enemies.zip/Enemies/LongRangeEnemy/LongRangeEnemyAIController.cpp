// Fill out your copyright notice in the Description page of Project Settings.


#include "LongRangeEnemyAIController.h"
#include "InjureNinja/Enemies/BlackboardKeys.h"
#include "BehaviorTree/BehaviorTreeComponent.h"
#include "BehaviorTree/BehaviorTree.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "UObject/ConstructorHelpers.h"
#include "Perception/AIPerceptionStimuliSourceComponent.h"
// Perception 
#include "Perception/AISenseConfig_Sight.h"
#include "Perception/AIPerceptionStimuliSourceComponent.h"
#include "Perception/AIPerceptionComponent.h"
// Controller
#include "GameFramework/Character.h"
#include "Runtime/Engine/Classes/Engine/World.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "AIController.h"


// Setup Behaviour Tree 
ALongRangeEnemyAIController::ALongRangeEnemyAIController ( FObjectInitializer const& object_initializer )
{
    // Find Behaviour Tree and assign to the variable
    static ConstructorHelpers::FObjectFinder<UBehaviorTree> obj ( TEXT ( "BehaviorTree'/Game/Enemy/Blueprints/BT_LongRangeEnemyBehaviorTree.BT_LongRangeEnemyBehaviorTree'" ) );

    if ( obj.Succeeded ( ) )
    {
        m_BehaviorTree = obj.Object;
    }

    // Create Behaviour Tree Comonent and Blackboard
    m_BehaviorTreeComponent = object_initializer.CreateDefaultSubobject<UBehaviorTreeComponent> ( this , TEXT ( "BehaviorComp" ) );
    m_Blackboard = object_initializer.CreateDefaultSubobject<UBlackboardComponent> ( this , TEXT ( "BlackboardComp" ) );

}

// Run Behaviour Tree
void ALongRangeEnemyAIController::BeginPlay ( )
{
    Super::BeginPlay ( );

    // Run Behaviour Tree
    RunBehaviorTree ( m_BehaviorTree );
    m_BehaviorTreeComponent->StartTree ( *m_BehaviorTree );
}

// Initialize blackboard 
void ALongRangeEnemyAIController::OnPossess ( APawn* const pawn )
{
    Super::OnPossess ( pawn );

    // Initialize blackboard 
    if ( m_Blackboard )
    {                                                                   
        m_Blackboard->InitializeBlackboard ( *m_BehaviorTree->BlackboardAsset );
    }
}

// Getter for Blackboard
UBlackboardComponent* ALongRangeEnemyAIController::GetBlackboard ( ) const
{
    return m_Blackboard;
}

// Updating chEnemyIsSafe's value
void ALongRangeEnemyAIController::OnUpdateSafeDistance ( bool bbkey_result )
{
    GetBlackboard()->SetValueAsBool(BlackboardKeys::chEnemyIsSafe,bbkey_result);
}

// Updating chAttackTarget's value
void ALongRangeEnemyAIController::OnUpdateAttackTarget ( bool bbkey_result )
{
    GetBlackboard()->SetValueAsBool(BlackboardKeys::chAttackTarget,bbkey_result);
}

// Updating chEnemyIsAttacking's value
void ALongRangeEnemyAIController::OnUpdateIsAttacking ( bool bbkey_result )
{
    GetBlackboard()->SetValueAsBool(BlackboardKeys::chEnemyIsAttacking,bbkey_result);
}
