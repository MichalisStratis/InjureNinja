// Fill out your copyright notice in the Description page of Project Settings.

#include "EnemyRetreat.h"
#include "InjureNinja/Enemies/LongRangeEnemy/LongRangeEnemyAIController.h"
#include "InjureNinja/Enemies/LongRangeEnemy/LongRangeEnemy.h"
#include "InjureNinja/Enemies/EnemyBase.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Blueprint/AIBlueprintHelperLibrary.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "Runtime/NavigationSystem/Public/NavigationSystem.h"
#include "InjureNinja/Enemies/BlackboardKeys.h"


UEnemyRetreat::UEnemyRetreat ( FObjectInitializer const& object_initializer )
{
	NodeName = TEXT ( "Enemy Retreat" );
}

EBTNodeResult::Type UEnemyRetreat::ExecuteTask ( UBehaviorTreeComponent& owner_comp, uint8* node_memory )
{
	// get player character and the NPC's controller
	ACharacter* const player = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
 	auto const cont = Cast<ALongRangeEnemyAIController>(owner_comp.GetAIOwner());
	auto const npc = Cast<ALongRangeEnemy> ( cont->GetPawn ( ) );


	// get player location to use as an origin
	FVector const player_location = player->GetActorLocation();

	// Find Random location away from player 
	FNavLocation loc;
	int iRandX=FMath::RandRange ( -1000,1000 );  
	int iRandY=FMath::RandRange ( 800,1000 );
	FVector v3PlayerPosition = FVector ( player_location.X + iRandX, player_location.Y + iRandY, player_location.Z );

	// get the navigation system 
	UNavigationSystemV1* const nav_sys = UNavigationSystemV1::GetCurrent(GetWorld());

	// set new retreat location
	cont->GetBlackboard()->SetValueAsVector(BlackboardKeys::chRetreatLocation, v3PlayerPosition);
	
	// finish with success
	FinishLatentTask(owner_comp, EBTNodeResult::Succeeded);
	return EBTNodeResult::Succeeded;
}
