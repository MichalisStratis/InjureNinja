// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/Tasks/BTTask_BlackboardBase.h"
#include "EnemyRetreat.generated.h"

/**
 * 
 */
UCLASS(Blueprintable)
class INJURENINJA_API UEnemyRetreat : public UBTTask_BlackboardBase
{
	GENERATED_BODY()

public:

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	UEnemyRetreat
	// Author 				:	Michalis Stratis
	// Purpose 				:	Constructor
	//-----------------------------------------------------------------------------------------------------------------------------
	UEnemyRetreat(FObjectInitializer const& object_initializer);

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	ExecuteTask
	// Author 				:	UE4
	// Editors              :   Michalis Stratis
	// Purpose 				:	Function that executes task for the behaviour tree.
	//-----------------------------------------------------------------------------------------------------------------------------
	EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& owner_comp, uint8* node_memory) override;
	
};
