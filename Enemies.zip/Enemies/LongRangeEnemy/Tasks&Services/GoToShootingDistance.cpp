// Fill out your copyright notice in the Description page of Project Settings.


#include "GoToShootingDistance.h"
#include "InjureNinja/Enemies/LongRangeEnemy/LongRangeEnemyAIController.h"
#include "InjureNinja/Enemies/LongRangeEnemy/LongRangeEnemy.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Blueprint/AIBlueprintHelperLibrary.h"
#include "InjureNinja/Enemies/BlackBoardKeys.h"


UGoToShootingDistance::UGoToShootingDistance(FObjectInitializer const& object_initializer)
{
	NodeName = TEXT("Go To Shooting Distance");
}

EBTNodeResult::Type UGoToShootingDistance::ExecuteTask(UBehaviorTreeComponent& owner_comp, uint8* node_memory)
{
	// get TargetLocation from blackboard via AI controller
	auto const cont = Cast<ALongRangeEnemyAIController>(owner_comp.GetAIOwner());	   

	FVector const player_location = GetWorld()->GetFirstPlayerController( )->GetPawn( )->GetActorLocation( );

	GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Yellow, TEXT("I I FOLLOW"));

	// move to the player's location
	cont->MoveToLocation(player_location, 600.F, true );

	// finish with success
	FinishLatentTask(owner_comp, EBTNodeResult::Succeeded);
	return EBTNodeResult::Succeeded;
}
