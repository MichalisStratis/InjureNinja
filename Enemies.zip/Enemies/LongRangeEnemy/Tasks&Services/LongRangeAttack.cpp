// Fill out your copyright notice in the Description page of Project Settings.


#include "LongRangeAttack.h"
#include "InjureNinja/Enemies/LongRangeEnemy/LongRangeEnemyAIController.h"
#include "InjureNinja/Enemies/LongRangeEnemy/LongRangeEnemy.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Runtime/Engine/Classes/Engine/World.h"
#include "Engine/LatentActionManager.h"
#include "Components/SkeletalMeshComponent.h"
#include "Animation/AnimMontage.h"
#include "Animation/AnimInstance.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "GameFramework/Character.h"
#include "Runtime/Engine/Classes/Engine/World.h"
#include "InjureNinja/Enemies/BlackboardKeys.h"
#include "BehaviorTree/BlackboardComponent.h"
#include <cmath>


ULongRangeAttack::ULongRangeAttack(FObjectInitializer const& object_initializer)
{
	NodeName = TEXT("Long Range Attack");
}

EBTNodeResult::Type ULongRangeAttack::ExecuteTask ( UBehaviorTreeComponent& owner_comp, uint8* node_memory )
{
	// get NPC
	auto const cont = Cast<ALongRangeEnemyAIController>(owner_comp.GetAIOwner());	
	ALongRangeEnemy* const npc = Cast<ALongRangeEnemy> ( cont->GetPawn ( ) );

	// Checks if montage is finished
	if ( MontageFinished(npc) )
	{
		if ( npc->GetMontage() )
		{
			// Playing the montage
			npc->PlayAnimMontage ( npc->GetMontage(), 1 );
		}
		// Changing the blackboard key's value
		cont->GetBlackboard()->SetValueAsBool(BlackboardKeys::chEnemyIsAttacking,true);
	}

	// Finish task succesfully 
	FinishLatentTask(owner_comp, EBTNodeResult::Succeeded);
	return EBTNodeResult::Succeeded;
}

bool ULongRangeAttack::MontageFinished ( ALongRangeEnemy* const npc )
{
	// Returns boolean depending if the montage is finished
	return npc->GetMesh()->GetAnimInstance()->Montage_GetIsStopped(npc->GetMontage());
}

