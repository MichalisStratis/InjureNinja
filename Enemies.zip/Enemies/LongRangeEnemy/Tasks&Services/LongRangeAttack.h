// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/Tasks/BTTask_BlackboardBase.h"
#include "BehaviorTree/BehaviorTreeComponent.h"
#include "BehaviorTree/BehaviorTreeTypes.h"
#include "UObject/UObjectGlobals.h"
#include "InjureNinja/Enemies/EnemyBase.h"
#include "LongRangeAttack.generated.h"

/**
 * 
 */
class ALongRangeEnemy;
UCLASS(Blueprintable)
class INJURENINJA_API ULongRangeAttack : public UBTTask_BlackboardBase
{
	GENERATED_BODY()
public:

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	ULongRangeAttack
	// Author 				:	Michalis Stratis
	// Purpose 				:	Constructor
	//-----------------------------------------------------------------------------------------------------------------------------
	ULongRangeAttack(FObjectInitializer const& object_initializer);
	
	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	ExecuteTask
	// Author 				:	UE4
	// Editors              :   Michalis Stratis
	// Purpose 				:	Function that executes task for the behaviour tree.
	//-----------------------------------------------------------------------------------------------------------------------------
	EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& owner_comp, uint8* node_memory) override;

private:

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	MontageFinished
	// Author 				:	Michalis Stratis
	// Purpose 				:	Checks if montage is finished ad returns boolean
	//-----------------------------------------------------------------------------------------------------------------------------
	bool MontageFinished(ALongRangeEnemy* const npc);
	
};
