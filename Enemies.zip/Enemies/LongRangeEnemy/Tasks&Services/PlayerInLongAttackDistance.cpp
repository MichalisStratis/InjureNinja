// Fill out your copyright notice in the Description page of Project Settings.


#include "PlayerInLongAttackDistance.h"
#include "InjureNinja/Enemies/LongRangeEnemy/LongRangeEnemyAIController.h"
#include "InjureNinja/Enemies/LongRangeEnemy/LongRangeEnemy.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "GameFramework/Character.h"
#include "Runtime/Engine/Classes/Engine/World.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "InjureNinja/Enemies/BlackboardKeys.h"
#include <cmath>


UPlayerInLongAttackDistance::UPlayerInLongAttackDistance()
{
    bNotifyBecomeRelevant = true;
    NodeName = TEXT("Is Player in Long Attck Distance");
}


void UPlayerInLongAttackDistance::TickNode ( UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds )
{
    Super::TickNode ( OwnerComp , NodeMemory , DeltaSeconds );

    // Get AI Controller and Enemy Pawn
    auto const controller = Cast<ALongRangeEnemyAIController> ( OwnerComp.GetAIOwner ( ) );
    ALongRangeEnemy* const npc = Cast<ALongRangeEnemy> ( controller->GetPawn ( ) );

    // Calculate Location
    FVector attackTargetLocation = GetWorld()->GetFirstPlayerController( )->GetPawn( )->GetActorLocation( );;
    float distanceToAttackLocation = FVector::Dist ( npc->GetActorLocation ( ) , attackTargetLocation );

    if ( distanceToAttackLocation <= m_fLongAttackDistance )
    {
        //controller->OnUpdateSafeDistance ( true );
        //GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Green, TEXT("IS IN LONG ATTACK DISTANCE"));
    }
    else
    {
        //controller->OnUpdateSafeDistance (false );
        //GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Red, TEXT("NOT IN LONG ATTACK DISTANCE"));
    }
}

