// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "EnemyBase.h"
#include "Struct_EnemyProperties.generated.h"


USTRUCT(BlueprintType)
struct FStructEnemyProperties
{
	GENERATED_BODY()

		// 
	UPROPERTY(EditInstanceOnly, BlueprintReadOnly)
		TEnumAsByte<EnemyType> Type;

	// 
	UPROPERTY(EditInstanceOnly, BlueprintReadOnly)
		int MaxAmountToSpawn = 0;

	// 
	UPROPERTY(EditInstanceOnly, BlueprintReadOnly)
		int CurrentSpawned = 0;
};