// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Struct_EnemyProperties.h"
#include "Struct_WaveProperties.generated.h"

USTRUCT(BlueprintType)
struct FStructWaveProperties
{
	GENERATED_BODY()

	// Enemies to spawn.
	UPROPERTY(Category = Weapons, EditAnywhere, meta = (DisplayName = "Enemies to Spawn"))
		TArray<FStructEnemyProperties> Enemies;

	// The amount of enemies to be killed before next chunk of enemies.
	UPROPERTY(EditInstanceOnly, BlueprintReadOnly)
		int ChunkThreshold = 0;

	// The amount of enemies to be killed before next chunk of enemies.
	UPROPERTY(EditInstanceOnly, BlueprintReadOnly)
		int AmountToSpawnEachChunk = 0;

};