// Fill out your copyright notice in the Description page of Project Settings.


#include "SumoAIController.h"
// Fill out your copyright notice in the Description page of Project Settings.
#include "InjureNinja/Enemies/BlackboardKeys.h"
#include "BehaviorTree/BehaviorTreeComponent.h"
#include "BehaviorTree/BehaviorTree.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "UObject/ConstructorHelpers.h"
// Controller
#include "Runtime/Engine/Classes/Engine/World.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"


// Setup Behaviour Tree 
ASumoAIController::ASumoAIController ( FObjectInitializer const& object_initializer )
{
    // Find Behaviour Tree and assign to the variable
    static ConstructorHelpers::FObjectFinder<UBehaviorTree> obj ( TEXT ( "BehaviorTree'/Game/Enemy/Blueprints/BT_SumoBehaviourTree.BT_SumoBehaviourTree'" ) );

    if ( obj.Succeeded ( ) )
    {
        m_BehaviorTree = obj.Object;
    }

    // Create Behaviour Tree Comonent and Blackboard
    m_BehaviorTreeComponent = object_initializer.CreateDefaultSubobject<UBehaviorTreeComponent> ( this , TEXT ( "BehaviorComp" ) );
    m_Blackboard = object_initializer.CreateDefaultSubobject<UBlackboardComponent> ( this , TEXT ( "BlackboardComp" ) );

}

// Run Behaviour Tree
void ASumoAIController::BeginPlay ( )
{
    Super::BeginPlay ( );

    // Run Behaviour Tree
    RunBehaviorTree ( m_BehaviorTree );
    m_BehaviorTreeComponent->StartTree ( *m_BehaviorTree );
}

// Initialize blackboard 
void ASumoAIController::OnPossess ( APawn* const pawn )
{
    Super::OnPossess ( pawn );

    // Initialize blackboard 
    if ( m_Blackboard )
    {                                                                   
        m_Blackboard->InitializeBlackboard ( *m_BehaviorTree->BlackboardAsset );
    }
}

// Getter for Blackboard
UBlackboardComponent* ASumoAIController::GetBlackboard ( ) const
{
    return m_Blackboard;
}

// Updates chSumoInRange's value
void ASumoAIController::OnUpdateInRange( bool bbkey_result )
{    
    GetBlackboard()->SetValueAsBool(BlackboardKeys::chSumoInRange,bbkey_result);
}
