// Fill out your copyright notice in the Description page of Project Settings.
#include "SumoAttack.h"
#include "AIController.h"
#include "InjureNinja/Enemies/SumoWrestler/SumoAIController.h"
#include "InjureNinja/Enemies/SumoWrestler/SumoWrestler.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "Runtime/Engine/Classes/Engine/World.h"
#include "InjureNinja/Enemies/BlackboardKeys.h"
#include "BehaviorTree/BlackboardComponent.h"
#include <cmath>


USumoAttack::USumoAttack(FObjectInitializer const& object_initializer)
{
	NodeName = TEXT("Sumo Attack");
}

EBTNodeResult::Type USumoAttack::ExecuteTask ( UBehaviorTreeComponent& owner_comp, uint8* node_memory )
{
	// get NPC
	ASumoAIController* const cont = Cast<ASumoAIController>(owner_comp.GetAIOwner());	
	ASumoWrestler* const npc = Cast<ASumoWrestler> ( cont->GetPawn ( ) );


	// If the no montages are currently playing sumo attacks and the task is succesful
	if (!MontagePlaying(npc))
	{
		npc->Attack();
		FinishLatentTask(owner_comp, EBTNodeResult::Succeeded);
		return EBTNodeResult::Succeeded;
	}
	return EBTNodeResult::Failed;
}

bool USumoAttack::MontagePlaying(ASumoWrestler* const npc)
{
	// Is montage currently playing?
	return npc->GetMesh()->GetAnimInstance()->IsAnyMontagePlaying();
}



