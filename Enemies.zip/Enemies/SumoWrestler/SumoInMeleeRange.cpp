// Fill out your copyright notice in the Description page of Project Settings.


#include "SumoInMeleeRange.h"
#include "InjureNinja/Enemies/SumoWrestler/SumoAIController.h"                        
#include "InjureNinja/Enemies/SumoWrestler/SumoWrestler.h"
#include "InjureNinja/InjureNinjaCharacter.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "GameFramework/Character.h"
#include "Runtime/Engine/Classes/Engine/World.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "InjureNinja/Enemies/BlackboardKeys.h"
#include <cmath>

USumoInMeleeRange::USumoInMeleeRange ( )
{
    // Naming node in engine
    NodeName = TEXT("Sumo In Melee Range");
}

void USumoInMeleeRange::TickNode ( UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds )
{
    Super::TickNode ( OwnerComp , NodeMemory , DeltaSeconds );

    // Get AI Controller and Enemy Pawn
    auto const controller = Cast<ASumoAIController> ( OwnerComp.GetAIOwner ( ) );
    auto const npc = Cast<AEnemyBase> ( controller->GetPawn ( ) );

    // Find Location
    FVector attackTargetLocation = GetWorld()->GetFirstPlayerController( )->GetPawn( )->GetActorLocation( );

    // Calculate distance
    auto distanceToAttackLocation = FVector::Dist ( npc->GetActorLocation ( ) , attackTargetLocation );

    // Compare distance to melee range and assign value to bbkey accordingly
    if ( distanceToAttackLocation <= melee_range )
    {
        controller->OnUpdateInRange ( true );
    }
    else
    {
        controller->OnUpdateInRange ( false );
    }
}

