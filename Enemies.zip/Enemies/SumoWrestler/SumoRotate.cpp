// Fill out your copyright notice in the Description page of Project Settings.


#include "SumoRotate.h"
#include "SumoWrestler.h"
#include "SumoAIController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Runtime/NavigationSystem/Public/NavigationSystem.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Vector.h"
#include "GameFramework/Character.h"
#include "InjureNinja/Enemies/BlackboardKeys.h"

USumoRotate::USumoRotate(FObjectInitializer const& object_initializer)
{
	NodeName = TEXT("Rotate To Face The Player");
}

EBTNodeResult::Type USumoRotate::ExecuteTask(UBehaviorTreeComponent& owner_comp, uint8* node_memory)
{
	// get player character and the NPC's controller
	ACharacter* const player = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
	auto const cont = Cast<ASumoAIController>(owner_comp.GetAIOwner());
	AEnemyBase* const npc = Cast<AEnemyBase> ( cont->GetPawn ( ) );

	// Find rotation and apply it to enemy 
	FVector Direction = player->GetActorLocation( ) - npc->GetActorLocation();
	FRotator PlayerRot = FRotationMatrix::MakeFromX(Direction).Rotator(); 
	npc->SetActorRotation(PlayerRot);

	// finish with success
	FinishLatentTask(owner_comp, EBTNodeResult::Succeeded);
	return EBTNodeResult::Succeeded;
}


