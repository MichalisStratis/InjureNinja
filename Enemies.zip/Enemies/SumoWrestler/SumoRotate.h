// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "SumoRotate.generated.h"

/**
 * 
 */
UCLASS()
class INJURENINJA_API USumoRotate : public UBTTaskNode
{
	GENERATED_BODY()
public:
	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	USumoRotate
	// Author 				:	Michalis Stratis
	// Purpose 				:	Constructor
	//-----------------------------------------------------------------------------------------------------------------------------
	USumoRotate ( FObjectInitializer const& object_initializer );

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	ExecuteTask
	// Author 				:	UE4
	// Editors              :   Michalis Stratis
	// Purpose 				:	Function that executes task for the behaviour tree.
	//-----------------------------------------------------------------------------------------------------------------------------
	EBTNodeResult::Type ExecuteTask ( UBehaviorTreeComponent& owner_comp, uint8* node_memory );
};
