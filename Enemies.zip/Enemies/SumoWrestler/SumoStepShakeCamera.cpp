// Fill out your copyright notice in the Description page of Project Settings.


#include "SumoStepShakeCamera.h"
#include "InjureNinja/Player/PlayerCharacter.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"

void USumoStepShakeCamera::Notify ( )
{
	GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Emerald, TEXT("SHAKE")); 
	player = Cast<APlayerCharacter> ( UGameplayStatics::GetPlayerCharacter ( GetWorld ( ), 0 ) );
	player->ShakeCamera( );
}
