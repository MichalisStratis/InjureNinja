// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "SumoStepShakeCamera.generated.h"

/**
 * 
 */
UCLASS()
class INJURENINJA_API USumoStepShakeCamera : public UAnimNotify
{
	GENERATED_BODY()

public:

	class APlayerCharacter* player;

	UFUNCTION(Category = Toggling, BlueprintCallable)
		virtual void Notify( );
	
};
