// Fill out your copyright notice in the Description page of Project Settings.


#include "SumoTaunt.h"
#include "AIController.h"
#include "InjureNinja/Enemies/SumoWrestler/SumoAIController.h"
#include "InjureNinja/Enemies/SumoWrestler/SumoWrestler.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Animation/AnimInstance.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "Runtime/Engine/Classes/Engine/World.h"
#include "InjureNinja/Enemies/BlackboardKeys.h"
#include "GameFramework/Actor.h"
#include "BehaviorTree/BlackboardComponent.h"
#include <cmath>


USumoTaunt::USumoTaunt(FObjectInitializer const& object_initializer)
{
	// Naming node in engine
	NodeName = TEXT("Sumo Taunt");
}

EBTNodeResult::Type USumoTaunt::ExecuteTask ( UBehaviorTreeComponent& owner_comp, uint8* node_memory )
{
	// get NPC
	ASumoAIController* const cont = Cast<ASumoAIController>(owner_comp.GetAIOwner());	
	ASumoWrestler* const npc = Cast<ASumoWrestler> ( cont->GetPawn ( ) );
	
	// Stops all montages if any and calls taunt() before ending task succesfully
	if ( MontagePlaying(npc) )
	{
		StopMontage ( npc );
		npc->Taunt();
		FinishLatentTask(owner_comp, EBTNodeResult::Succeeded);
		return EBTNodeResult::Succeeded;
	}
	return EBTNodeResult::Failed;
}

void USumoTaunt::StopMontage ( ASumoWrestler* const npc )
{
	// Stops current montage
	npc->GetMesh ( )->GetAnimInstance ( )->Montage_Stop ( 0, npc->GetMesh ( )->GetAnimInstance ( )->GetCurrentActiveMontage ( ) );
}

bool USumoTaunt::MontagePlaying ( ASumoWrestler* const npc )
{
	// Is any montage playing?
	return npc->GetMesh()->GetAnimInstance()->IsAnyMontagePlaying();
}
