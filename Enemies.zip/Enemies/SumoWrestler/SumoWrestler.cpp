#include "SumoWrestler.h"
#include "Components/BoxComponent.h"
#include "Components/ActorComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "SumoAIController.h"
#include "InjureNinja/Player/PlayerCharacter.h"
#include "InjureNinja/Enemies/BlackboardKeys.h"
#include "InjureNinja/InjureNinjaCharacter.h"

ASumoWrestler::ASumoWrestler ( )
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
}

void ASumoWrestler::BeginPlay ( )
{
	Super::BeginPlay();

	AttackCollider->OnComponentBeginOverlap.AddDynamic ( this, &ASumoWrestler::OnOverlapAttackBegin );
	AttackCollider->OnComponentEndOverlap.AddDynamic ( this, &ASumoWrestler::OnOverlapAttackEnd );
}

void ASumoWrestler::Tick ( float DeltaTime )
{
	Super::Tick(DeltaTime);
}

void ASumoWrestler::OnOverlapAttackBegin ( UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult )
{
	// if overlaps with player set boolean to true
	if(OtherActor->IsA<APlayerCharacter>())
	{
		IsOverlapping=true;
	}
}

void ASumoWrestler::OnOverlapAttackEnd ( UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex )
{
	// set boolean to false
	IsOverlapping=false;
}

void ASumoWrestler::Attack ( )
{
	// Play montage from array based on random number
	int iRandMontage = FMath::RandRange(0, AttackMontages.Num() - 1);
	PlayAnimMontage(AttackMontages[iRandMontage], 1);

	// Cast player and damage him 
	APlayerCharacter* player = Cast<APlayerCharacter>(GetWorld()->GetFirstPlayerController()->GetPawn());
	player->DamagePlayer(30);
	
	// Disabling collider and setting player to null pointer
	DisableAttackBox();
	player = nullptr;
}

void ASumoWrestler::Taunt ( )
{
	// Play montage from array based on random number
	int iRandMontage = FMath::RandRange(0, TauntMontages.Num() - 1);
	PlayAnimMontage(TauntMontages[iRandMontage], 1);
}

UAnimMontage* ASumoWrestler::GetAttackMontage ( ) const
{
	// Get current montage
	return GetMesh()->GetAnimInstance()->GetCurrentActiveMontage( );
}
