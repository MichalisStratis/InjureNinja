// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "InjureNinja/Enemies/EnemyBase.h"
#include "SumoWrestler.generated.h"

class UBoxComponent;

UCLASS()
class INJURENINJA_API ASumoWrestler : public AEnemyBase
{
	GENERATED_BODY()

public:

	virtual void BeginPlay() override;

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	ASumoWrestler
	// Author 				:	Michalis Stratis
	// Purpose 				:	Constructor
	//-----------------------------------------------------------------------------------------------------------------------------
	ASumoWrestler ( );

	// Array of attack montages
	UPROPERTY(Category = Montages, EditAnywhere, meta = (DisplayName = "Attack Montages"))
		TArray<UAnimMontage*> AttackMontages;

	// Array of taunt montages
	UPROPERTY(Category = Montages, EditAnywhere, meta = (DisplayName = "Taunt Montages"))
		TArray<UAnimMontage*> TauntMontages;

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	GetAttackMontage
	// Author 				:	Michalis Stratis
	// Purpose 				:	Getter for current active montage
	//-----------------------------------------------------------------------------------------------------------------------------
	UAnimMontage* GetAttackMontage ( ) const;

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	Attack
	// Author 				:	Michalis Stratis
	// Purpose 				:	Attacks player to damage him
	//-----------------------------------------------------------------------------------------------------------------------------
	void Attack ( );

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	UEnemyRetreat
	// Author 				:	Michalis Stratis
	// Purpose 				:	Plays taunting anim montages
	//-----------------------------------------------------------------------------------------------------------------------------
	void Taunt ( );

	// is sumo overlapping
	bool IsOverlapping;

protected:

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	Tick
	// Author 				:	UE4
	// Editors              :   Michalis Stratis
	// Purpose 				:	Function that gets called every frame.
	//-----------------------------------------------------------------------------------------------------------------------------
	virtual void Tick ( float DeltaTime ) override;

private:

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	OnOverlapAttackBegin, OnOverlapAttackEnd
	// Author 				:	UE4
	// Editors              :   Michalis Stratis
	// Purpose 				:	Function that gets called when actors overlap.
	//-----------------------------------------------------------------------------------------------------------------------------
	UFUNCTION ( )
		void OnOverlapAttackBegin ( UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION ( )
		void OnOverlapAttackEnd(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

};
