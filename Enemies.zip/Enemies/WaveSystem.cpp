// Fill out your copyright notice in the Description page of Project Settings.


#include "WaveSystem.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "InjureNinja/Player/PlayerCharacter.h"
#include "InjureNinja/Player/PlayerHUD.h"

// Sets default values
AWaveSystem::AWaveSystem()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AWaveSystem::BeginPlay()
{
	Super::BeginPlay();
	
	// Set the starting properties.
	m_iCurrentEnemyKillCount = 0;
	m_iCurrentWave = -1;
	m_bLoadNextWave = true;

	// Create the enemy pool.
	CreateEnemyPool();

	// Cast to the player.
	m_pcPlayerCharacter = Cast<APlayerCharacter>(UGameplayStatics::GetActorOfClass(GetWorld(), APlayerCharacter::StaticClass()));
}

// Called every frame
void AWaveSystem::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	m_fDeltaTime = DeltaTime;

	WaveTimer();
}

void AWaveSystem::EnemyKilled()
{
	// Increase enemy counters.
	m_iCurrentEnemyKillCount++;
	m_iCurrentChunkKills++;

	//GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Yellow, FString::Printf(TEXT("%d, %d"), m_iCurrentEnemyKillCount, m_iEnemiesToBeKilled));

	// Check if the next chunk is to be loaded.
	if (m_iCurrentChunkKills == Waves[m_iCurrentWave].ChunkThreshold && m_iCurrentEnemyKillCount != m_iEnemiesToBeKilled)
	{
		LoadNextChunk();
	}
	else
	{
		// Check if the enemies have all been killed from the current wave.
		if (m_iCurrentEnemyKillCount == m_iEnemiesToBeKilled)
		{
			m_bLoadNextWave = true;
		}
		// LOAD NEXT WAVE
	}
}

void AWaveSystem::CreateEnemyPool()
{ 
	// Create the enemy pool from the specified enemy blueprints and counts.
	for (int i = 0; i < 3; i++)
	{
		switch (i)
		{
		case 0:
			for (int j = 0; j < CloseRangeCount; j++)
			{
				Enemies.Add(GetWorld()->SpawnActor<AEnemyBase>(CloseRangeTemplate));
				
			}
			break;
		case 1:
			for (int j = 0; j < LongRangeCount; j++)
			{
				Enemies.Add(GetWorld()->SpawnActor<AEnemyBase>(LongRangeTemplate));
			}
			break;
		case 2:
			for (int j = 0; j < SumoCount; j++)
			{
				Enemies.Add(GetWorld()->SpawnActor<AEnemyBase>(SumoTemplate));
			}
			break;
		}
	}
}

void AWaveSystem::LoadNextWave()
{
	// Reset current kill count.
	m_iCurrentEnemyKillCount = 0;
	m_iCurrentChunkKills = 0;

	// Reset enemies spawned count.
	m_iEnemiesSpawned = 0;
	m_iEnemiesToBeKilled = 0;

	// Increment and load to the next wave.
	m_iCurrentWave++;
	m_pcPlayerCharacter->GetHUD()->NextWave(m_iCurrentWave + 1);

	// Play the next wave SFX.
	UGameplayStatics::PlaySound2D(GetWorld(), SFXNextRound, 1);

	for (int i = 0; i < Waves[m_iCurrentWave].Enemies.Num(); i++)
	{
		// Calculate the enemies to be killed this wave.
		m_iEnemiesToBeKilled += Waves[m_iCurrentWave].Enemies[i].MaxAmountToSpawn;
	}

	// Begin spawning the enemies.
	LoadNextChunk();
}

void AWaveSystem::LoadNextChunk()
{
	// Reset current chunk kills.
	m_iCurrentChunkKills = 0;

	// Locate an enemy in the pool to spawn.
	FindEnemy();
}

void AWaveSystem::FindEnemy()
{
	// Reset current chunk spawned.
	m_iCurrentChunkSpawned = 0;

	// Loop until amount to spawn each chunk is met.
	while (m_iCurrentChunkSpawned < Waves[m_iCurrentWave].AmountToSpawnEachChunk)
	{
		// Double check the correct amount of enemies are spawned.
		if (m_iEnemiesSpawned < m_iEnemiesToBeKilled)
		{
			// Spawn random enemy type.
			int iRandEnemyType = FMath::RandRange(0, Waves[m_iCurrentWave].Enemies.Num() - 1);

			// Find and spawn the enemy.
			if (Waves[m_iCurrentWave].Enemies[iRandEnemyType].CurrentSpawned < Waves[m_iCurrentWave].Enemies[iRandEnemyType].MaxAmountToSpawn)
			{
				AEnemyBase* pcEnemy = Cast<AEnemyBase>(GetEnemyOfType(Waves[m_iCurrentWave].Enemies[iRandEnemyType].Type));
				if (pcEnemy)
				{
					// Choose random spawn position.
					int iRandSpawnPos = FMath::FRandRange(0, SpawnPositions.Num());
					pcEnemy->SpawnEnemy(SpawnPositions[iRandSpawnPos]->GetActorLocation());
					Waves[m_iCurrentWave].Enemies[iRandEnemyType].CurrentSpawned++;
					iRandEnemyType = 0;

					// Increase spawned tracker.
					m_iEnemiesSpawned++;
					m_iCurrentChunkSpawned++;

					//GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Yellow, FString::FromInt(m_iEnemiesSpawned));
				}
			}
		}
		else
		{
			break;
		}
	}
}

void AWaveSystem::WaveTimer()
{
	// Manages the countdown for the next wave.
	if (m_bLoadNextWave)
	{
		m_fWaveCountdown += m_fDeltaTime;
		if (m_fWaveCountdown > TimeBetweenWaves)
		{
			LoadNextWave();
			m_fWaveCountdown = 0;
			m_bLoadNextWave = false;
		}
	}
}

AEnemyBase* AWaveSystem::GetEnemyOfType(EnemyType eEnemyType)
{
	// Loop through the entire enemy array.
	for (int i = 0; i < Enemies.Num(); i++)
	{
		// Check the type of enemy is the type specified, as well as if the enemy is inactive (ready to be spawned).
		if (Enemies[i]->GetType() == eEnemyType && !Enemies[i]->GetActiveState())
		{
			//GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Yellow, TEXT("ENEMY FOUND."));
			return Enemies[i];
		}
	}
	//GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Yellow, TEXT("ENEMY NOT FOUND."));
	return nullptr;
}

