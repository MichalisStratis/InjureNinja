// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Struct_WaveProperties.h"
#include "WaveSystem.generated.h"

class APlayerCharacter;

UCLASS()
class INJURENINJA_API AWaveSystem : public AActor
{
	GENERATED_BODY()

	// Time between waves.
	UPROPERTY(Category = "Wave Properties", EditAnywhere)
		int TimeBetweenWaves = 10;

	// Spawn position of enemies.
	UPROPERTY(Category = "Wave Properties", EditAnywhere, meta = (DisplayName = "Spawn Positions"))
		TArray<AActor*> SpawnPositions;

	// Wave manager.
	UPROPERTY(Category = "Wave Properties", EditAnywhere, meta = (DisplayName = "Wave Manager"))
		TArray<FStructWaveProperties> Waves;

	// Close range enemies to spawn in the pool.
	UPROPERTY(EditAnywhere)
		int CloseRangeCount = 25;

	// Long range enemies to spawn in the pool.
	UPROPERTY(EditAnywhere)
		int LongRangeCount = 25;

	// Sumo enemies to spawn in the pool.
	UPROPERTY(EditAnywhere)
		int SumoCount = 5;

	// Close range enemy blueprint.
	UPROPERTY(Category = Enemies, EditAnywhere, meta = (DisplayName = "Close Range Template"))
	TSubclassOf<AEnemyBase> CloseRangeTemplate;

	// Long range enemy blueprint.
	UPROPERTY(Category = Enemies, EditAnywhere, meta = (DisplayName = "Long Range Template"))
	TSubclassOf<AEnemyBase> LongRangeTemplate;

	// Sumo enemy blueprint.
	UPROPERTY(Category = Enemies, EditAnywhere, meta = (DisplayName = "Sumo Template"))
	TSubclassOf<AEnemyBase> SumoTemplate;

	// Enemies spawning in the pool.
	UPROPERTY(Category = Enemies, EditAnywhere, meta = (DisplayName = "Enemy Array"))
	TArray<AEnemyBase*> Enemies;

	// Sound effect to play when new round begins.
	UPROPERTY(EditAnywhere, Category = "Sound Effects")
		USoundWave* SFXNextRound;

protected:
	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	OnBeginOverlapTrigger
	// Author 				:	Unreal Engine
	// Purpose 				:	Function that is called at game start.
	//-----------------------------------------------------------------------------------------------------------------------------
	virtual void BeginPlay() override;

public:
	//-----------------------------------------------------------------------------------------------------------------------------
	// Constructor Name		:	AWaveSystem
	// Author 				:	Kurtis Watson
	// Purpose 				:	Sets default values for this actor's properties.
	//-----------------------------------------------------------------------------------------------------------------------------
	AWaveSystem();	

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	Tick
	// Author 				:	Unreal Engine
	// Purpose 				:	Function that is called on collision.
	// Parameters			:	DeltaTime - Describes the time difference between the previous frame that was drawn and the 
	//							current frame.
	//-----------------------------------------------------------------------------------------------------------------------------
	virtual void Tick(float DeltaTime) override;

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	EnemyKilled
	// Author 				:	Kurtis Watson
	// Purpose 				:	Called when the wave system needs alerting of an enemy death.	
	//-----------------------------------------------------------------------------------------------------------------------------
	void EnemyKilled();

private:
	// Pointers to class instances in game.
	APlayerCharacter* m_pcPlayerCharacter;

	float m_fWaveCountdown = 0;
	float m_fDeltaTime = 0;

	// Load next wave bool.
	bool m_bLoadNextWave = true;

	// Enemy counters.
	int m_iCurrentEnemyKillCount = 0;
	int m_iCurrentChunkSpawned = 0;
	int m_iCurrentChunkKills = 0;
	int m_iEnemiesSpawned = 0;
	int m_iEnemiesToBeKilled = 0;
	
	// Wave tracker.
	int m_iCurrentWave = 0;

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	CreateEnemyPool
	// Author 				:	Kurtis Watson
	// Purpose 				:	Creates the pool of enemies that will be cycled through at runtime.
	//-----------------------------------------------------------------------------------------------------------------------------
	void CreateEnemyPool();

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	LoadNextWave
	// Author 				:	Kurtis Watson
	// Purpose 				:	Loads the next wave.
	//-----------------------------------------------------------------------------------------------------------------------------
	void LoadNextWave();

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	LoadNextChunk
	// Author 				:	Kurtis Watson
	// Purpose 				:	Loads the next chunk that is linked to the current wave.
	//-----------------------------------------------------------------------------------------------------------------------------
	void LoadNextChunk();

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	FindEnemy
	// Author 				:	Kurtis Watson
	// Purpose 				:	Find and spawns an enemy.
	//-----------------------------------------------------------------------------------------------------------------------------
	void FindEnemy();

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	WaveTimer
	// Author 				:	Kurtis Watson
	// Purpose 				:	Handles the wave timing.
	//-----------------------------------------------------------------------------------------------------------------------------
	void WaveTimer();

	//-----------------------------------------------------------------------------------------------------------------------------
	// Function Name		:	GetEnemyOfType
	// Author 				:	Kurtis Watson
	// Purpose 				:	Returns and enemy of the specified type.
	//-----------------------------------------------------------------------------------------------------------------------------
	AEnemyBase* GetEnemyOfType(EnemyType eEnemyType);

};
